import random

class Actr:
    name = "you forgot to add a name retard"
    atk = 0
    defense = 0
    hp = 0
    mhp = 0
    mp = 0
    str = 0
    mmp = 0
    agi = 0
    armor = 0
    attacks = []
    magic = {}
    abilities = {}
    items = []
    dice = 2
    extraATKdice = 0
    extraSTRdice = 0
    extraHEALdice = 0
    turnover = False
    isguarding = False
    wavetokens = 0
    tidetokens = 0
    def __init__(self, name, atk, defense, hp, mhp, mp, str, mmp, agi, armor, attacks=[], magic={}, abilities={}, items=[], dice=2):
        self.name = name
        self.atk = atk
        self.defense = defense
        self.hp = hp
        self.mhp = mhp
        self.mp = mp
        self.str = str
        self.mmp = mmp
        self.agi = agi
        self.armor = armor
        self.attacks = attacks
        self.magic = magic
        self.abilities = abilities
        self.items = items
        self.dice = dice

    def mpallocationincrement(self, pc):


        if (self.mp < 3 and pc.mp > 0):
            self.mp += 1
            pc.mp -= 1
        else:
            self.mp += 0

    def mpallocationdecrement(self, pc):
        if (self.mp > 0 and pc.mp < 5):
            self.mp -= 1
            pc.mp += 1
        else:
            self.mp -= 0

    def attack(self, attackstring):
        diceroll = []
        if (self.atk == 0):
            return 0
        print("minorhere")
        if (attackstring == "Attack" or attackstring == "Wave Crash(3MP)"):
            # roll dice many 6 sided die and add your attack stat
            print("HERE")
            for i in range(1, self.dice + 1 + self.extraATKdice):  # Roll "DICE" many times. e.g. if dice = 3, you roll 3 dice
                diceroll.append(random.randrange(1, 6 + 1))  # roll a 6 sided dice
            self.extraATKdice = 0
            return diceroll  # Return the attack number result

    def damage(self, targetactr = None):
        diceroll = []
        if(targetactr!=None):
            if(targetactr.isguarding == True):
                self.dice -=1
        for i in range(1, self.dice + 1 + self.extraSTRdice):  # Roll "DICE" many times. e.g. if dice = 3, you roll 3 dice
            diceroll.append(random.randrange(1, 6 + 1))  # roll a 6 sided dice
        self.extraSTRdice = 0
        if(targetactr!=None):
            if (targetactr.isguarding == True):
                self.dice +=1
        return diceroll  # Return the damage number result

    def ismagicbuff(self, magicstring):
        if(self.magic[magicstring] == "BUFF"):
            return True
        else:
            return False

    def magicbuff(self,magicstring):
        #Return name,mp,dice
        if(magicstring.lower() == "One On One(1MP)".lower()): #Dice buff +1 dice on next attack roll for choice
            return "ATKDICEBUFF", 1
        if(magicstring.lower() == "Man Eater(1MP)".lower()):
            return "DMGDICEBUFF", 1
        if(magicstring.lower() == "Underswell(2MP)".lower()):
            return "HEAL", 2, 2
        if(magicstring.lower() == "Riptide(3MP)".lower()):
            return "HEAL", 3, 3

    def magicattacktype(self, magicstring):

        if(magicstring.lower() == "Wave Crash(3MP)".lower()):
            return "DMG", 3




    def heal(self,dice):
        healroll = []
        for i in range(1,dice+1):
            healroll.append(random.randrange(1,6+1))
        return healroll

    def magicdamage(self,magicstring):
        if(magicstring.lower() == "Wave Crash(3MP)".lower()):
            diceroll = []
            for i in range(1,self.dice + 1 + self.extraSTRdice):  # Roll "DICE" many times. e.g. if dice = 3, you roll 3 dice
                diceroll.append(random.randrange(1, 6 + 1))  # roll a 6 sided dice

            self.extraSTRdice = 0
            return diceroll  # Return the damage number result and the extra damage the spell does